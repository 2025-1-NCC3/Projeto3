const { MongoClient, ObjectId } = require("mongodb");
const bcrypt = require("bcryptjs"); // Adicionado para hashing de senha

let singletonDb;

async function connect() {
  if (singletonDb) return singletonDb;

  if (!process.env.MONGO_HOST || !process.env.MONGO_DATABASE) {
    console.error("ERRO: As variáveis de ambiente MONGO_HOST e MONGO_DATABASE devem estar definidas.");
    process.exit(1);
  }

  const client = new MongoClient(process.env.MONGO_HOST);
  await client.connect();
  singletonDb = client.db(process.env.MONGO_DATABASE);
  console.log(`Conectado à base de dados: ${process.env.MONGO_DATABASE}`);
  return singletonDb;
}

// --- Funções para Passageiros ---
async function insertPassageiro(passageiro) {
  const db = await connect();
  
  // CORREÇÃO: Aplicar hash na senha antes de salvar
  if (passageiro.senha) {
    const salt = await bcrypt.genSalt(10);
    passageiro.senha = await bcrypt.hash(passageiro.senha, salt);
    console.log("Senha hasheada com sucesso antes de salvar no banco");
  }
  
  return db.collection("passageiros").insertOne(passageiro);
}

async function findAllPassageiros() {
  const db = await connect();
  return db.collection("passageiros").find().toArray();
}

async function findPassageiroById(id) {
  const db = await connect();
  return db.collection("passageiros").findOne({ _id: new ObjectId(id) });
}

async function findPassageiroByEmail(email) {
    const db = await connect();
    return db.collection("passageiros").findOne({ email: email });
}

async function updatePassageiro(id, dadosAtualizados) {
  const db = await connect();
  const { _id, ...updateData } = dadosAtualizados;
  
  // CORREÇÃO: Aplicar hash na senha se estiver sendo atualizada
  if (updateData.senha) {
    const salt = await bcrypt.genSalt(10);
    updateData.senha = await bcrypt.hash(updateData.senha, salt);
    console.log("Senha hasheada com sucesso antes de atualizar no banco");
  }
  
  return db.collection("passageiros").updateOne({ _id: new ObjectId(id) }, { $set: updateData });
}

async function removePassageiro(id) {
  const db = await connect();
  return db.collection("passageiros").deleteOne({ _id: new ObjectId(id) });
}

// --- Funções para Motoristas ---
async function insertMotorista(motorista) {
  const db = await connect();
  
  // CORREÇÃO: Aplicar hash na senha se motoristas tiverem login
  if (motorista.senha) {
    const salt = await bcrypt.genSalt(10);
    motorista.senha = await bcrypt.hash(motorista.senha, salt);
  }
  
  return db.collection("motoristas").insertOne(motorista);
}

async function findAllMotoristas() {
  const db = await connect();
  return db.collection("motoristas").find().toArray();
}

async function findMotoristaById(id) {
  const db = await connect();
  return db.collection("motoristas").findOne({ _id: new ObjectId(id) });
}

async function updateMotorista(id, dadosAtualizados) {
  const db = await connect();
  const { _id, ...updateData } = dadosAtualizados;
  
  // CORREÇÃO: Aplicar hash na senha se estiver sendo atualizada
  if (updateData.senha) {
    const salt = await bcrypt.genSalt(10);
    updateData.senha = await bcrypt.hash(updateData.senha, salt);
  }
  
  return db.collection("motoristas").updateOne({ _id: new ObjectId(id) }, { $set: updateData });
}

async function removeMotorista(id) {
  const db = await connect();
  return db.collection("motoristas").deleteOne({ _id: new ObjectId(id) });
}

// --- Funções para Cadastros (Utilizadores Genéricos - se ainda for usado) ---
async function insertCadastro(cadastro) {
  const db = await connect();
  
  // CORREÇÃO: Aplicar hash na senha
  if (cadastro.senha) {
    const salt = await bcrypt.genSalt(10);
    cadastro.senha = await bcrypt.hash(cadastro.senha, salt);
  }
  
  return db.collection("cadastros").insertOne(cadastro);
}

async function findAllCadastros() {
  const db = await connect();
  return db.collection("cadastros").find().project({ senha: 0 }).toArray();
}

async function findCadastroById(id) {
  const db = await connect();
  return db.collection("cadastros").findOne({ _id: new ObjectId(id) }, { projection: { senha: 0 } });
}

async function findCadastroByEmail(email) {
  const db = await connect();
  return db.collection("cadastros").findOne({ email: email });
}

async function updateCadastro(id, dadosAtualizados) {
  const db = await connect();
  const { _id, ...updateData } = dadosAtualizados;
  
  // CORREÇÃO: Aplicar hash na senha se estiver sendo atualizada
  if (updateData.senha) {
    const salt = await bcrypt.genSalt(10);
    updateData.senha = await bcrypt.hash(updateData.senha, salt);
  }
  
  return db.collection("cadastros").updateOne({ _id: new ObjectId(id) }, { $set: updateData });
}

async function removeCadastro(id) {
  const db = await connect();
  return db.collection("cadastros").deleteOne({ _id: new ObjectId(id) });
}

// --- Funções para Avaliações de Viagens (entre Passageiro e Motorista) ---
async function insertAvaliacao(avaliacao) {
  const db = await connect();
  if (avaliacao.passageiroId) avaliacao.passageiroId = new ObjectId(avaliacao.passageiroId);
  if (avaliacao.motoristaId) avaliacao.motoristaId = new ObjectId(avaliacao.motoristaId);
  return db.collection("avaliacoes").insertOne(avaliacao);
}

async function findAllAvaliacoes() {
  const db = await connect();
  return db.collection("avaliacoes").find().toArray();
}

async function findAvaliacaoById(id) {
  const db = await connect();
  return db.collection("avaliacoes").findOne({ _id: new ObjectId(id) });
}

async function findAvaliacoesByMotoristaId(motoristaId) {
  const db = await connect();
  return db.collection("avaliacoes").find({ motoristaId: new ObjectId(motoristaId) }).toArray();
}

async function findAvaliacoesByPassageiroId(passageiroId) {
  const db = await connect();
  return db.collection("avaliacoes").find({ passageiroId: new ObjectId(passageiroId) }).toArray();
}

async function updateAvaliacao(id, dadosAtualizados) {
  const db = await connect();
  const { _id, ...updateData } = dadosAtualizados;
  return db.collection("avaliacoes").updateOne({ _id: new ObjectId(id) }, { $set: updateData });
}

async function removeAvaliacao(id) {
  const db = await connect();
  return db.collection("avaliacoes").deleteOne({ _id: new ObjectId(id) });
}

// --- Funções para Zonas Geográficas ---
async function insertZona(zona) {
  const db = await connect();
  zona.dataCriacao = new Date();
  zona.dataAtualizacao = new Date();
  return db.collection("zonas").insertOne(zona);
}

async function findAllZonas() {
  const db = await connect();
  return db.collection("zonas").find().toArray();
}

async function findZonaById(id) {
  const db = await connect();
  return db.collection("zonas").findOne({ _id: new ObjectId(id) });
}

async function findZonaByNome(nome, cidade = "São Paulo") {
    const db = await connect();
    return db.collection("zonas").findOne({ nome: nome, cidade: cidade });
}

async function updateZona(id, dadosAtualizados) {
  const db = await connect();
  dadosAtualizados.dataAtualizacao = new Date();
  const { _id, ...updateData } = dadosAtualizados;
  return db.collection("zonas").updateOne({ _id: new ObjectId(id) }, { $set: updateData });
}

async function removeZona(id) {
  const db = await connect();
  return db.collection("zonas").deleteOne({ _id: new ObjectId(id) });
}

// --- Funções para Avaliações de Zonas ---
async function insertAvaliacaoDeZona(avaliacaoDeZona) {
  const db = await connect();
  avaliacaoDeZona.zonaId = new ObjectId(avaliacaoDeZona.zonaId);
  avaliacaoDeZona.usuarioId = new ObjectId(avaliacaoDeZona.usuarioId);
  avaliacaoDeZona.dataAvaliacao = new Date();
  avaliacaoDeZona.ativa = true; // Por defeito, uma nova avaliação está ativa
  return db.collection("avaliacoesDeZonas").insertOne(avaliacaoDeZona);
}

async function findAvaliacoesByZonaIdRecentes(zonaId) {
  const db = await connect();
  const umMesAtras = new Date();
  umMesAtras.setMonth(umMesAtras.getMonth() - 1);
  return db.collection("avaliacoesDeZonas")
    .find({
      zonaId: new ObjectId(zonaId),
      dataAvaliacao: { $gte: umMesAtras },
      ativa: true
    })
    .sort({ dataAvaliacao: -1 })
    .toArray();
}

async function findAvaliacoesDeZonaByUsuarioId(usuarioId) {
  const db = await connect();
  return db.collection("avaliacoesDeZonas")
    .find({ usuarioId: new ObjectId(usuarioId) })
    .sort({ dataAvaliacao: -1 })
    .toArray();
}

module.exports = {
  connect,
  // Passageiro
  insertPassageiro,
  findAllPassageiros,
  findPassageiroById,
  findPassageiroByEmail,
  updatePassageiro,
  removePassageiro,
  // Motorista
  insertMotorista,
  findAllMotoristas,
  findMotoristaById,
  updateMotorista,
  removeMotorista,
  // Cadastro (se ainda usado)
  insertCadastro,
  findAllCadastros,
  findCadastroById,
  findCadastroByEmail,
  updateCadastro,
  removeCadastro,
  // Avaliação de Viagem
  insertAvaliacao,
  findAllAvaliacoes,
  findAvaliacaoById,
  findAvaliacoesByMotoristaId,
  findAvaliacoesByPassageiroId,
  updateAvaliacao,
  removeAvaliacao,
  // Zonas Geográficas
  insertZona,
  findAllZonas,
  findZonaById,
  findZonaByNome,
  updateZona,
  removeZona,
  // Avaliações de Zonas
  insertAvaliacaoDeZona,
  findAvaliacoesByZonaIdRecentes,
  findAvaliacoesDeZonaByUsuarioId
};