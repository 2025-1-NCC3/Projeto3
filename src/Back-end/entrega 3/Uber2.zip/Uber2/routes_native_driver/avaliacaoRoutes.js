const express = require("express");
const router = express.Router();
const db = require("../database_user_provided"); // Ajustar o caminho se necessário
const { ObjectId } = require("mongodb");

// POST /api/avaliacoes - Criar uma nova avaliação
router.post("/", async (req, res) => {
  try {
    const novaAvaliacao = req.body;
    // Validação básica dos campos obrigatórios
    if (!novaAvaliacao.passageiroId || !novaAvaliacao.motoristaId || !novaAvaliacao.nota) {
      return res.status(400).json({ message: "passageiroId, motoristaId e nota são obrigatórios." });
    }
    if (!ObjectId.isValid(novaAvaliacao.passageiroId) || !ObjectId.isValid(novaAvaliacao.motoristaId)) {
        return res.status(400).json({ message: "passageiroId ou motoristaId inválido." });
    }
    if (typeof novaAvaliacao.nota !== 'number' || novaAvaliacao.nota < 1 || novaAvaliacao.nota > 5) {
        return res.status(400).json({ message: "A nota deve ser um número entre 1 e 5." });
    }

    // Opcional: Verificar se o passageiro e motorista existem no banco de dados
    // const passageiro = await db.findPassageiroById(novaAvaliacao.passageiroId);
    // if (!passageiro) return res.status(404).json({ message: "Passageiro não encontrado." });
    // const motorista = await db.findMotoristaById(novaAvaliacao.motoristaId);
    // if (!motorista) return res.status(404).json({ message: "Motorista não encontrado." });

    novaAvaliacao.dataAvaliacao = new Date();
    // A função insertAvaliacao no db module já trata a conversão para ObjectId
    const resultado = await db.insertAvaliacao(novaAvaliacao);

    if (resultado.insertedId) {
      res.status(201).json({ _id: resultado.insertedId, ...novaAvaliacao });
    } else {
      res.status(500).json({ message: "Erro ao criar avaliação." });
    }
  } catch (err) {
    console.error("Erro em POST /avaliacoes:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/avaliacoes - Obter todas as avaliações
router.get("/", async (req, res) => {
  try {
    const avaliacoes = await db.findAllAvaliacoes();
    // Para popular dados do passageiro/motorista, seria necessário lógica adicional aqui
    // ou modificar findAllAvaliacoes para usar $lookup se estiver a usar agregação.
    res.json(avaliacoes);
  } catch (err) {
    console.error("Erro em GET /avaliacoes:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/avaliacoes/:id - Obter uma avaliação por ID
router.get("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID da avaliação inválido." });
    }
    const avaliacao = await db.findAvaliacaoById(req.params.id);
    if (avaliacao) {
      res.json(avaliacao);
    } else {
      res.status(404).json({ message: "Avaliação não encontrada." });
    }
  } catch (err) {
    console.error(`Erro em GET /avaliacoes/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/avaliacoes/motorista/:motoristaId - Obter todas as avaliações de um motorista específico
router.get("/motorista/:motoristaId", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.motoristaId)) {
      return res.status(400).json({ message: "ID do motorista inválido." });
    }
    const avaliacoes = await db.findAvaliacoesByMotoristaId(req.params.motoristaId);
    res.json(avaliacoes);
  } catch (err) {
    console.error(`Erro em GET /avaliacoes/motorista/${req.params.motoristaId}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/avaliacoes/passageiro/:passageiroId - Obter todas as avaliações feitas por um passageiro específico
router.get("/passageiro/:passageiroId", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.passageiroId)) {
      return res.status(400).json({ message: "ID do passageiro inválido." });
    }
    const avaliacoes = await db.findAvaliacoesByPassageiroId(req.params.passageiroId);
    res.json(avaliacoes);
  } catch (err) {
    console.error(`Erro em GET /avaliacoes/passageiro/${req.params.passageiroId}:`, err);
    res.status(500).json({ message: err.message });
  }
});


// PUT /api/avaliacoes/:id - Atualizar uma avaliação por ID
router.put("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID da avaliação inválido." });
    }
    const dadosAtualizados = req.body;
    delete dadosAtualizados._id; // Não permitir atualização do _id
    // Não permitir alteração de passageiroId ou motoristaId numa avaliação existente
    delete dadosAtualizados.passageiroId;
    delete dadosAtualizados.motoristaId;
    delete dadosAtualizados.dataAvaliacao;

    if (dadosAtualizados.nota !== undefined && (typeof dadosAtualizados.nota !== 'number' || dadosAtualizados.nota < 1 || dadosAtualizados.nota > 5)) {
        return res.status(400).json({ message: "A nota deve ser um número entre 1 e 5." });
    }

    const resultado = await db.updateAvaliacao(req.params.id, dadosAtualizados);
    if (resultado.matchedCount > 0) {
        if (resultado.modifiedCount > 0) {
            const avaliacaoAtualizada = await db.findAvaliacaoById(req.params.id);
            res.json(avaliacaoAtualizada);
        } else {
            const avaliacaoExistente = await db.findAvaliacaoById(req.params.id);
            res.json(avaliacaoExistente);
        }
    } else {
      res.status(404).json({ message: "Avaliação não encontrada para atualização." });
    }
  } catch (err) {
    console.error(`Erro em PUT /avaliacoes/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/avaliacoes/:id - Apagar uma avaliação por ID
router.delete("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID da avaliação inválido." });
    }
    const resultado = await db.removeAvaliacao(req.params.id);
    if (resultado.deletedCount > 0) {
      res.json({ message: "Avaliação apagada com sucesso." });
    } else {
      res.status(404).json({ message: "Avaliação não encontrada para apagar." });
    }
  } catch (err) {
    console.error(`Erro em DELETE /avaliacoes/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
