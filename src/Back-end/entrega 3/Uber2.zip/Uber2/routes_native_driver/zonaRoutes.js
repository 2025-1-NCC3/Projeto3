const express = require("express");
const router = express.Router();
const db = require("../database_user_provided");
const { ObjectId } = require("mongodb");

// POST /api/zonas - Criar uma nova zona (para administração)
router.post("/", async (req, res) => {
    try {
        const { nome, cidade, poligono } = req.body;
        if (!nome || !cidade || !poligono || !poligono.type || poligono.type !== 'Polygon' || !poligono.coordinates) {
            return res.status(400).json({ mensagem: "Nome, cidade e um polígono GeoJSON válido são obrigatórios." });
        }
        const novaZona = { nome, cidade, poligono };
        const resultado = await db.insertZona(novaZona);
        res.status(201).json({ mensagem: "Zona criada com sucesso!", zonaId: resultado.insertedId, zona: novaZona });
    } catch (error) {
        console.error("Erro ao criar zona:", error);
        if (error.code === 11000) {
             return res.status(409).json({ mensagem: `Zona '${req.body.nome}' já existe em '${req.body.cidade}'.` });
        }
        res.status(500).json({ mensagem: "Erro interno do servidor ao criar zona." });
    }
});

// GET /api/zonas - Listar todas as zonas
router.get("/", async (req, res) => {
    try {
        const zonas = await db.findAllZonas();
        res.status(200).json(zonas);
    } catch (error) {
        console.error("Erro ao listar zonas:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao listar zonas." });
    }
});

// GET /api/zonas/:id - Obter uma zona por ID
router.get("/:id", async (req, res) => {
    try {
        if (!ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ mensagem: "ID de zona inválido." });
        }
        const zona = await db.findZonaById(req.params.id);
        if (!zona) {
            return res.status(404).json({ mensagem: "Zona não encontrada." });
        }
        res.status(200).json(zona);
    } catch (error) {
        console.error("Erro ao buscar zona por ID:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao buscar zona." });
    }
});

// GET /api/zonas/nome/:nome - Obter uma zona por nome (cidade é opcional via query string)
router.get("/nome/:nome", async (req, res) => {
    try {
        const nomeZona = req.params.nome;
        // Cidade agora é um query parameter: /api/zonas/nome/Centro?cidade=São Paulo
        const cidade = req.query.cidade || "São Paulo"; // Default para São Paulo se não especificado
        
        const zona = await db.findZonaByNome(nomeZona, cidade);
        if (!zona) {
            return res.status(404).json({ mensagem: `Zona '${nomeZona}' não encontrada em '${cidade}'.` });
        }
        res.status(200).json(zona);
    } catch (error) {
        console.error("Erro ao buscar zona por nome:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao buscar zona por nome." });
    }
});

module.exports = router;
