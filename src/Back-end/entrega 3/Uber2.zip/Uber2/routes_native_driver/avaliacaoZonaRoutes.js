const express = require("express");
const router = express.Router();
const db = require("../database_user_provided");
const { ObjectId } = require("mongodb");

// POST /api/avaliacoes_zona - Submeter uma nova avaliação para uma zona
router.post("/", async (req, res) => {
    try {
        const { zonaId, usuarioId, tipoUsuario, classificacaoEstrelas, comentario, tipoAlerta, localizacaoAproximada } = req.body;

        // Validações básicas
        if (!zonaId || !usuarioId || !tipoUsuario || !classificacaoEstrelas) {
            return res.status(400).json({ mensagem: "zonaId, usuarioId, tipoUsuario e classificacaoEstrelas são obrigatórios." });
        }
        if (!ObjectId.isValid(zonaId)) {
            return res.status(400).json({ mensagem: "zonaId inválido." });
        }
        if (!ObjectId.isValid(usuarioId)) {
            return res.status(400).json({ mensagem: "usuarioId inválido." });
        }
        if (classificacaoEstrelas < 1 || classificacaoEstrelas > 5) {
            return res.status(400).json({ mensagem: "A classificação deve ser entre 1 e 5 estrelas." });
        }
        if (tipoUsuario !== 'passageiro' && tipoUsuario !== 'motorista'){
            return res.status(400).json({ mensagem: "tipoUsuario deve ser 'passageiro' ou 'motorista'." });
        }

        // TODO: Adicionar lógica para verificar se o utilizador esteve recentemente na zona (passo futuro)
        // TODO: Adicionar lógica para limitar a frequência de avaliação por utilizador/zona (passo futuro)

        const novaAvaliacaoDeZona = {
            zonaId,
            usuarioId,
            tipoUsuario,
            classificacaoEstrelas,
            comentario,
            tipoAlerta,
            localizacaoAproximada,
            // dataAvaliacao e ativa serão definidas pela função insertAvaliacaoDeZona
        };

        const resultado = await db.insertAvaliacaoDeZona(novaAvaliacaoDeZona);
        res.status(201).json({ mensagem: "Avaliação de zona submetida com sucesso!", avaliacaoId: resultado.insertedId, avaliacao: novaAvaliacaoDeZona });

    } catch (error) {
        console.error("Erro ao submeter avaliação de zona:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao submeter avaliação de zona." });
    }
});

// GET /api/avaliacoes_zona/zona/:zonaId - Listar avaliações recentes (último mês) de uma zona específica
router.get("/zona/:zonaId", async (req, res) => {
    try {
        const { zonaId } = req.params;
        if (!ObjectId.isValid(zonaId)) {
            return res.status(400).json({ mensagem: "zonaId inválido." });
        }

        const avaliacoes = await db.findAvaliacoesByZonaIdRecentes(zonaId);
        if (!avaliacoes) {
            // Retorna array vazio se não houver avaliações, o que é normal
            return res.status(200).json([]);
        }
        res.status(200).json(avaliacoes);

    } catch (error) {
        console.error("Erro ao listar avaliações da zona:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao listar avaliações da zona." });
    }
});

// GET /api/avaliacoes_zona/usuario/:usuarioId - Listar todas as avaliações de zona feitas por um utilizador
router.get("/usuario/:usuarioId", async (req, res) => {
    try {
        const { usuarioId } = req.params;
        if (!ObjectId.isValid(usuarioId)) {
            return res.status(400).json({ mensagem: "usuarioId inválido." });
        }

        const avaliacoes = await db.findAvaliacoesDeZonaByUsuarioId(usuarioId);
        if (!avaliacoes) {
            return res.status(200).json([]);
        }
        res.status(200).json(avaliacoes);

    } catch (error) {
        console.error("Erro ao listar avaliações do utilizador:", error);
        res.status(500).json({ mensagem: "Erro interno do servidor ao listar avaliações do utilizador." });
    }
});

module.exports = router;

