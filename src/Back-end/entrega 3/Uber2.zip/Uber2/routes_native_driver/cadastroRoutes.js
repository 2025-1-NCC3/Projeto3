const express = require("express");
const router = express.Router();
const db = require("../database_user_provided"); // Ajustar o caminho se necessário
const { ObjectId } = require("mongodb");
// Em uma aplicação real, aqui você integraria o hashing de senha (ex: bcryptjs)

// POST /api/cadastros - Criar um novo cadastro (Registo de Utilizador)
router.post("/", async (req, res) => {
  try {
    const novoCadastro = req.body;
    if (!novoCadastro.nome || !novoCadastro.email || !novoCadastro.senha) {
      return res.status(400).json({ message: "Nome, email e senha são obrigatórios." });
    }
    // Adicionar aqui a lógica de hashing para novoCadastro.senha antes de chamar db.insertCadastro
    // Ex: novoCadastro.senha = await bcrypt.hash(novoCadastro.senha, 10);
    console.warn("Lembre-se de implementar o hashing de senha para produção!");

    novoCadastro.dataRegisto = new Date();
    const resultado = await db.insertCadastro(novoCadastro);

    if (resultado.insertedId) {
      // Não retornar a senha na resposta
      const { senha, ...cadastroSemSenha } = novoCadastro;
      res.status(201).json({ _id: resultado.insertedId, ...cadastroSemSenha });
    } else {
      res.status(500).json({ message: "Erro ao criar cadastro." });
    }
  } catch (err) {
    console.error("Erro em POST /cadastros:", err);
    if (err.code === 11000) { // Código de erro para chave duplicada (ex: email)
        return res.status(409).json({ message: "Email já registado." });
    }
    res.status(500).json({ message: err.message });
  }
});

// GET /api/cadastros - Obter todos os cadastros (Proteger esta rota em produção)
router.get("/", async (req, res) => {
  try {
    const cadastros = await db.findAllCadastros(); // Função já remove a senha
    res.json(cadastros);
  } catch (err) {
    console.error("Erro em GET /cadastros:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/cadastros/:id - Obter um cadastro por ID (Proteger esta rota)
router.get("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const cadastro = await db.findCadastroById(req.params.id); // Função já remove a senha
    if (cadastro) {
      res.json(cadastro);
    } else {
      res.status(404).json({ message: "Cadastro não encontrado." });
    }
  } catch (err) {
    console.error(`Erro em GET /cadastros/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/cadastros/:id - Atualizar um cadastro por ID
router.put("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const dadosAtualizados = req.body;
    delete dadosAtualizados._id; // Não permitir atualização do _id

    // Se a senha estiver a ser atualizada, ela deve ser "hasheada"
    if (dadosAtualizados.senha) {
      console.warn("Atualização de senha detetada - Implementar hashing!");
      // Ex: dadosAtualizados.senha = await bcrypt.hash(dadosAtualizados.senha, 10);
    }

    const resultado = await db.updateCadastro(req.params.id, dadosAtualizados);
    if (resultado.matchedCount > 0) {
        if (resultado.modifiedCount > 0 || resultado.upsertedCount > 0) {
            const cadastroAtualizado = await db.findCadastroById(req.params.id);
            res.json(cadastroAtualizado); // Retorna o cadastro atualizado sem a senha
        } else {
            const cadastroExistente = await db.findCadastroById(req.params.id);
            res.json(cadastroExistente); // Nenhum campo foi modificado
        }
    } else {
      res.status(404).json({ message: "Cadastro não encontrado para atualização." });
    }
  } catch (err) {
    console.error(`Erro em PUT /cadastros/${req.params.id}:`, err);
    if (err.code === 11000) { // Conflito de chave única (ex: email)
        return res.status(409).json({ message: "Erro ao atualizar: O email fornecido já pode estar em uso por outra conta." });
    }
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/cadastros/:id - Apagar um cadastro por ID
router.delete("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const resultado = await db.removeCadastro(req.params.id);
    if (resultado.deletedCount > 0) {
      res.json({ message: "Cadastro apagado com sucesso." });
    } else {
      res.status(404).json({ message: "Cadastro não encontrado para apagar." });
    }
  } catch (err) {
    console.error(`Erro em DELETE /cadastros/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// POST /api/cadastros/login - Rota de Login (exemplo básico)
// Em uma aplicação real, esta rota retornaria um token JWT
router.post("/login", async (req, res) => {
    try {
        const { email, senha } = req.body;
        if (!email || !senha) {
            return res.status(400).json({ message: "Email e senha são obrigatórios." });
        }

        const utilizador = await db.findCadastroByEmail(email);
        if (!utilizador) {
            return res.status(401).json({ message: "Credenciais inválidas (email)." });
        }

        // Comparar a senha fornecida com a senha "hasheada" no banco de dados
        // Ex: const isMatch = await bcrypt.compare(senha, utilizador.senha);
        // Por agora, uma comparação direta (NÃO FAZER ISTO EM PRODUÇÃO)
        console.warn("Comparação de senha em texto plano no login - Implementar bcrypt para produção!");
        const isMatch = (senha === utilizador.senha); // Simulação, assumindo que a senha não está hasheada ou foi hasheada de forma reversível (não seguro)

        if (!isMatch) {
            return res.status(401).json({ message: "Credenciais inválidas (senha)." });
        }
        
        // Login bem-sucedido, remover senha antes de enviar resposta
        const { senha: _, ...utilizadorSemSenha } = utilizador;
        res.json({ message: "Login bem-sucedido!", utilizador: utilizadorSemSenha });

    } catch (err) {
        console.error("Erro em POST /cadastros/login:", err);
        res.status(500).json({ message: err.message });
    }
});


module.exports = router;
