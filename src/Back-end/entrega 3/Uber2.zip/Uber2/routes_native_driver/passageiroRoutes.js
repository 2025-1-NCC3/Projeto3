const express = require("express");
const router = express.Router();
const db = require("../database_user_provided"); 
const { ObjectId } = require("mongodb");
const bcrypt = require("bcryptjs"); // Certifique-se que bcryptjs está importado

// POST /api/passageiros - Criar um novo passageiro
router.post("/", async (req, res) => {
  try {
    const novoPassageiro = req.body;
    if (!novoPassageiro.nome || !novoPassageiro.email || !novoPassageiro.senha) {
      return res.status(400).json({ message: "Nome, email e senha são obrigatórios." });
    }
    // O hashing da senha agora é feito dentro da função db.insertPassageiro
    // conforme o arquivo database_user_provided_corrigido.js
    novoPassageiro.dataRegisto = new Date();
    const resultado = await db.insertPassageiro(novoPassageiro); // insertPassageiro fará o hash
    if (resultado.insertedId) {
      res.status(201).json({ _id: resultado.insertedId, nome: novoPassageiro.nome, email: novoPassageiro.email, dataRegisto: novoPassageiro.dataRegisto });
    } else {
      res.status(500).json({ message: "Erro ao criar passageiro." });
    }
  } catch (err) {
    console.error("Erro em POST /passageiros:", err.message, err.stack);
    res.status(500).json({ message: "Erro interno ao criar passageiro", error: err.message });
  }
});

// Rota POST para /login (será /api/passageiros/login por causa do prefixo no server.js)
router.post("/login", async (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).json({ msg: "Por favor, forneça email e senha." });
    }

    try {
        const passageiro = await db.findPassageiroByEmail(email); // Usando a função corrigida

        if (!passageiro) {
            return res.status(400).json({ msg: "Credenciais inválidas (usuário não encontrado)." });
        }

        const isMatch = await bcrypt.compare(senha, passageiro.senha);
        if (!isMatch) {
            return res.status(400).json({ msg: "Credenciais inválidas (senha incorreta)." });
        }

        const passageiroInfo = {
            id: passageiro._id,
            nome: passageiro.nome,
            email: passageiro.email
        };

        res.status(200).json({
            msg: "Login bem-sucedido!",
            passageiro: passageiroInfo
        });

    } catch (err) {
        console.error("Erro em POST /api/passageiros/login:", err.message, err.stack);
        res.status(500).json({ msg: "Erro interno no servidor durante o login", error: err.message });
    }
});

// GET /api/passageiros - Obter todos os passageiros
router.get("/", async (req, res) => {
  try {
    const passageiros = await db.findAllPassageiros();
    res.json(passageiros);
  } catch (err) {
    console.error("Erro em GET /passageiros:", err.message, err.stack);
    res.status(500).json({ message: "Erro interno ao buscar passageiros", error: err.message });
  }
});

// GET /api/passageiros/:id - Obter um passageiro por ID
router.get("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const passageiro = await db.findPassageiroById(req.params.id);
    if (passageiro) {
      res.json(passageiro);
    } else {
      res.status(404).json({ message: "Passageiro não encontrado." });
    }
  } catch (err) {
    console.error(`Erro em GET /passageiros/${req.params.id}:`, err.message, err.stack);
    res.status(500).json({ message: "Erro interno ao buscar passageiro por ID", error: err.message });
  }
});

// PUT /api/passageiros/:id - Atualizar um passageiro por ID
router.put("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const dadosAtualizados = req.body;
    // O hashing da senha (se presente) agora é feito dentro da função db.updatePassageiro
    const resultado = await db.updatePassageiro(req.params.id, dadosAtualizados);
    if (resultado.matchedCount > 0) {
        if (resultado.modifiedCount > 0) {
            const passageiroAtualizado = await db.findPassageiroById(req.params.id);
            res.json(passageiroAtualizado);
        } else {
            const passageiroExistente = await db.findPassageiroById(req.params.id);
            res.json(passageiroExistente); 
        }
    } else {
      res.status(404).json({ message: "Passageiro não encontrado para atualização." });
    }
  } catch (err) {
    console.error(`Erro em PUT /passageiros/${req.params.id}:`, err.message, err.stack);
    res.status(500).json({ message: "Erro interno ao atualizar passageiro", error: err.message });
  }
});

// DELETE /api/passageiros/:id - Apagar um passageiro por ID
router.delete("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const resultado = await db.removePassageiro(req.params.id);
    if (resultado.deletedCount > 0) {
      res.json({ message: "Passageiro apagado com sucesso." });
    } else {
      res.status(404).json({ message: "Passageiro não encontrado para apagar." });
    }
  } catch (err) {
    console.error(`Erro em DELETE /passageiros/${req.params.id}:`, err.message, err.stack);
    res.status(500).json({ message: "Erro interno ao apagar passageiro", error: err.message });
  }
});

module.exports = router;
