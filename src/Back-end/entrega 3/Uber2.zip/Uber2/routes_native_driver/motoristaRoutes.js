const express = require("express");
const router = express.Router();
const db = require("../database_user_provided"); // Ajustar o caminho se necessário
const { ObjectId } = require("mongodb");

// POST /api/motoristas - Criar um novo motorista
router.post("/", async (req, res) => {
  try {
    const novoMotorista = req.body;
    // Adicionar validação básica dos campos aqui, se necessário
    if (!novoMotorista.nome || !novoMotorista.email || !novoMotorista.numeroLicenca) {
      return res.status(400).json({ message: "Nome, email e número da licença são obrigatórios." });
    }
    novoMotorista.dataRegisto = new Date();
    novoMotorista.ativo = novoMotorista.ativo !== undefined ? novoMotorista.ativo : true;
    const resultado = await db.insertMotorista(novoMotorista);
    if (resultado.insertedId) {
      res.status(201).json({ _id: resultado.insertedId, ...novoMotorista });
    } else {
      res.status(500).json({ message: "Erro ao criar motorista." });
    }
  } catch (err) {
    console.error("Erro em POST /motoristas:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/motoristas - Obter todos os motoristas
router.get("/", async (req, res) => {
  try {
    const motoristas = await db.findAllMotoristas();
    res.json(motoristas);
  } catch (err) {
    console.error("Erro em GET /motoristas:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /api/motoristas/:id - Obter um motorista por ID
router.get("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const motorista = await db.findMotoristaById(req.params.id);
    if (motorista) {
      res.json(motorista);
    } else {
      res.status(404).json({ message: "Motorista não encontrado." });
    }
  } catch (err) {
    console.error(`Erro em GET /motoristas/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/motoristas/:id - Atualizar um motorista por ID
router.put("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const dadosAtualizados = req.body;
    delete dadosAtualizados._id;

    const resultado = await db.updateMotorista(req.params.id, dadosAtualizados);
    if (resultado.matchedCount > 0) {
        if (resultado.modifiedCount > 0) {
            const motoristaAtualizado = await db.findMotoristaById(req.params.id);
            res.json(motoristaAtualizado);
        } else {
            const motoristaExistente = await db.findMotoristaById(req.params.id);
            res.json(motoristaExistente);
        }
    } else {
      res.status(404).json({ message: "Motorista não encontrado para atualização." });
    }
  } catch (err) {
    console.error(`Erro em PUT /motoristas/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/motoristas/:id - Apagar um motorista por ID
router.delete("/:id", async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID inválido." });
    }
    const resultado = await db.removeMotorista(req.params.id);
    if (resultado.deletedCount > 0) {
      res.json({ message: "Motorista apagado com sucesso." });
    } else {
      res.status(404).json({ message: "Motorista não encontrado para apagar." });
    }
  } catch (err) {
    console.error(`Erro em DELETE /motoristas/${req.params.id}:`, err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
