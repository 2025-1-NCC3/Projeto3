# Estrutura do Projeto e Instruções (Driver Nativo MongoDB)

Este projeto contém as rotas de API para gerir Passageiros, Motoristas, Cadastros (Utilizadores) e Avaliações, utilizando Node.js, Express e o driver nativo do MongoDB. Esta versão foi adaptada para usar o teu módulo de base de dados fornecido.

## Estrutura de Pastas e Ficheiros

```
/
├── routes_native_driver/       # Contém os ficheiros de rotas para cada entidade
│   ├── passageiroRoutes.js
│   ├── motoristaRoutes.js
│   ├── cadastroRoutes.js
│   └── avaliacaoRoutes.js
├── database_user_provided.js   # O teu módulo de base de dados adaptado
├── server_native_driver.js     # Ficheiro principal da aplicação Express
├── .env                        # Ficheiro de variáveis de ambiente (PRECISAS CRIAR)
└── README.md                   # Este ficheiro
```

## Descrição dos Ficheiros

*   **`routes_native_driver/`**: Esta pasta contém os ficheiros que definem as rotas da API (endpoints) para cada entidade, utilizando o Express Router e as funções do `database_user_provided.js`.
    *   `passageiroRoutes.js`: Rotas CRUD para passageiros.
    *   `motoristaRoutes.js`: Rotas CRUD para motoristas.
    *   `cadastroRoutes.js`: Rotas CRUD para cadastros/utilizadores. Inclui uma rota `/login` básica e menções sobre hashing de senha.
    *   `avaliacaoRoutes.js`: Rotas CRUD para avaliações, com validação de IDs e campos.

*   **`database_user_provided.js`**: O teu módulo de ligação à base de dados original, que foi adaptado para incluir funções CRUD (Create, Read, Update, Delete) para as coleções `passageiros`, `motoristas`, `cadastros`, e `avaliacoes`. Ele usa o driver nativo do MongoDB para interagir com a base de dados definida pelas variáveis de ambiente `MONGO_HOST` e `MONGO_DATABASE`.

*   **`server_native_driver.js`**: É o ponto de entrada da aplicação. Configura o servidor Express, inicializa a ligação à base de dados através do `database_user_provided.js`, regista os middlewares (como `express.json()`) e monta as rotas definidas na pasta `routes_native_driver/`.

*   **`.env` (PRECISAS CRIAR)**: Este ficheiro é crucial e deves criá-lo na raiz do teu projeto. Ele armazenará as tuas variáveis de ambiente. Para este projeto, ele deve conter:
    ```env
    MONGO_HOST=mongodb://127.0.0.1:27017
    MONGO_DATABASE=servidoruber
    PORT=3000
    ```
    Podes ajustar a `PORT` se necessário.

## Como Executar

1.  **Instalar Dependências**: Certifica-te de que tens o Node.js e o npm (ou yarn) instalados. No teu terminal, na raiz do projeto, executa:
    ```bash
    npm install express mongodb dotenv
    ```
    *   `express`: Framework web.
    *   `mongodb`: O driver oficial do MongoDB para Node.js.
    *   `dotenv`: Para carregar variáveis de ambiente do ficheiro `.env`.

2.  **Criar o ficheiro `.env`**: Na raiz do teu projeto, cria um ficheiro chamado `.env` com o seguinte conteúdo (conforme as tuas configurações):
    ```env
    MONGO_HOST=mongodb://127.0.0.1:27017
    MONGO_DATABASE=servidoruber
    PORT=3000
    ```

3.  **Configurar MongoDB**: Certifica-te de que tens uma instância do MongoDB a correr e acessível no `MONGO_HOST` que definiste (por defeito, `mongodb://127.0.0.1:27017`). A base de dados `servidoruber` será criada automaticamente na primeira vez que uma operação de escrita for realizada, se ainda não existir.

4.  **Iniciar o Servidor**: Execute o seguinte comando no terminal, a partir da raiz do projeto:
    ```bash
    node server_native_driver.js
    ```
    Se tudo estiver configurado corretamente, deverás ver mensagens na consola a indicar que o servidor está a correr na porta especificada e que a ligação ao MongoDB (`servidoruber`) foi bem-sucedida.

## Endpoints da API (Exemplos)

O servidor irá expor os seguintes endpoints base (por defeito na porta 3000):

*   **Passageiros** (`/api/passageiros`):
    *   `POST /` - Criar novo passageiro
    *   `GET /` - Listar todos os passageiros
    *   `GET /:id` - Obter passageiro por ID
    *   `PUT /:id` - Atualizar passageiro por ID
    *   `DELETE /:id` - Apagar passageiro por ID

*   **Motoristas** (`/api/motoristas`):
    *   `POST /` - Criar novo motorista
    *   `GET /` - Listar todos os motoristas
    *   `GET /:id` - Obter motorista por ID
    *   `PUT /:id` - Atualizar motorista por ID
    *   `DELETE /:id` - Apagar motorista por ID

*   **Cadastros (Utilizadores)** (`/api/cadastros`):
    *   `POST /` - Registar novo utilizador
    *   `GET /` - Listar todos os utilizadores (a senha é omitida)
    *   `GET /:id` - Obter utilizador por ID (a senha é omitida)
    *   `PUT /:id` - Atualizar utilizador por ID
    *   `DELETE /:id` - Apagar utilizador por ID
    *   `POST /login` - Endpoint de login (básico, requer implementação de hashing de senha e tokens JWT para produção)

*   **Avaliações** (`/api/avaliacoes`):
    *   `POST /` - Criar nova avaliação
    *   `GET /` - Listar todas as avaliações
    *   `GET /:id` - Obter avaliação por ID
    *   `GET /motorista/:motoristaId` - Listar avaliações de um motorista
    *   `GET /passageiro/:passageiroId` - Listar avaliações de um passageiro
    *   `PUT /:id` - Atualizar avaliação por ID
    *   `DELETE /:id` - Apagar avaliação por ID

## Considerações Adicionais

*   **Segurança de Senhas**: Para as rotas de `cadastroRoutes.js`, a gestão de senhas (hashing com `bcryptjs` ou similar) é crucial e foi mencionada nos comentários do código, mas não implementada. **Não uses comparação de senhas em texto plano em produção.**
*   **Autenticação e Autorização**: Para um sistema real, precisarias de implementar autenticação (ex: com JWT - JSON Web Tokens) para proteger rotas e identificar utilizadores autenticados, e autorização para controlar o que cada utilizador pode fazer.
*   **Validação de Dados**: Foram adicionadas validações básicas. Considera usar bibliotecas como `joi` ou `express-validator` para validações mais robustas e declarativas.
*   **Tratamento de Erros**: O tratamento de erros é funcional. Pode ser centralizado e melhorado com middlewares de erro mais específicos.

Espero que esta estrutura adaptada ao teu módulo de base de dados seja útil para o teu trabalho!
