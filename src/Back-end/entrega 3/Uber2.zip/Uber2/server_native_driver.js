require("dotenv").config(); // Para carregar variáveis do .env no início

const express = require("express");
const cors = require("cors"); // Importar o pacote cors
const db = require("./database_user_provided"); // O teu módulo de base de dados

// Importar as rotas criadas
const passageiroRoutes = require("./routes_native_driver/passageiroRoutes");
const motoristaRoutes = require("./routes_native_driver/motoristaRoutes");
const cadastroRoutes = require("./routes_native_driver/cadastroRoutes");
const avaliacaoRoutes = require("./routes_native_driver/avaliacaoRoutes");
const zonaRoutes = require("./routes_native_driver/zonaRoutes"); // Novas rotas para Zonas
const avaliacaoZonaRoutes = require("./routes_native_driver/avaliacaoZonaRoutes"); // Novas rotas para Avaliações de Zonas

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para permitir parsing de JSON
app.use(express.json());

// Habilitar CORS para todas as rotas
app.use(cors()); // Adicionar antes das rotas

// Rota de teste inicial
app.get("/", (req, res) => {
  res.send("API ServidorUber a funcionar com driver nativo MongoDB!");
});

// Montar as rotas da API
app.use("/api/passageiros", passageiroRoutes);
app.use("/api/motoristas", motoristaRoutes);
app.use("/api/cadastros", cadastroRoutes);
app.use("/api/avaliacoes", avaliacaoRoutes); // Avaliações entre passageiro/motorista
app.use("/api/zonas", zonaRoutes); // Rotas para gerir Zonas Geográficas
app.use("/api/avaliacoes_zona", avaliacaoZonaRoutes); // Rotas para gerir Avaliações de Zonas

// Função para iniciar o servidor após conectar à DB
async function startServer() {
  try {
    await db.connect(); // Conecta à base de dados usando a função do teu módulo
    app.listen(PORT, () => {
      console.log(`Servidor a correr na porta ${PORT}`);
      console.log(`MONGO_HOST: ${process.env.MONGO_HOST}`);
      console.log(`MONGO_DATABASE: ${process.env.MONGO_DATABASE}`);
    });
  } catch (error) {
    console.error("Falha ao conectar à base de dados ou iniciar o servidor:", error);
    process.exit(1); // Sair se não conseguir conectar à DB
  }
}

// Iniciar o servidor
startServer();

